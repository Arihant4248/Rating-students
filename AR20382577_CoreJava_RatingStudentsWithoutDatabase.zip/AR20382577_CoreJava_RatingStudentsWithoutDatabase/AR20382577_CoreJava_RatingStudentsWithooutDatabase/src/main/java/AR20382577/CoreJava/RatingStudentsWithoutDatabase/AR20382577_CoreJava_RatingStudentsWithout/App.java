package BH40133423.CoreJava.RatingStudentsWithooutDatabase.BH40133423_CoreJava_RatingStudentsWithooutDatabase;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
