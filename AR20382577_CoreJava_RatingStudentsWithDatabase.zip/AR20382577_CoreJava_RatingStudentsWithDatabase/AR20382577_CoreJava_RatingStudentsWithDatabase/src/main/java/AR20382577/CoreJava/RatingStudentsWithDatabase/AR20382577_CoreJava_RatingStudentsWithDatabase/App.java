package BH40133423.CoreJava.RatingStudentsWithDatabase.BH40133423_CoreJava_RatingStudentsWithDatabase;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
